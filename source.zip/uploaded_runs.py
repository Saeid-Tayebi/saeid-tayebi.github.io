"""Run visitor-selected columns through the unmodified upstream implementations."""
import sys
import numpy as np
from uploads import selected_data

def run_uploaded(tool,params,upload,selection):
 from runner import validate,REPOS,VENDOR,scatter,bars,metric,rmse
 p=validate(tool,params);X,Y,names,outputs,selection=selected_data(upload,tool,selection,p)
 np.random.seed(42);sys.path.insert(0,str(VENDOR/REPOS[tool]));n,d=X.shape
 out={'repo':REPOS[tool],'settings':{'data':'Uploaded file','rows':n,'inputs':d},'charts':[],'metrics':[],'table':{},'config':{'inputs':names,'outputs':outputs,'settings':p},'uploaded':True}
 out['dataset']=f'Your uploaded data: {n} observations; inputs: '+', '.join(names)+('. Outputs/actions: '+', '.join(outputs) if outputs else '')+'. No synthetic observations are substituted. '
 if tool=='missing':
  from PCAFill.pca_fill import pca_fill
  mask=np.isnan(X);complete=~mask.any(1)
  if not mask.any():raise ValueError('The selected columns have no missing cells. Leave missing values blank in the file, or try the built-in validation example.')
  if complete.sum()<max(10,d+3):raise ValueError('Keep at least 10 complete rows (and at least inputs + 3) to fit the PCA estimator.')
  if mask.all(1).any():raise ValueError('Each row must have at least one observed input value.')
  if np.any(np.std(X[complete],axis=0)<1e-10):raise ValueError('Complete calibration rows contain a constant input column.')
  filled=pca_fill(X)
  if not np.isfinite(filled).all():raise ValueError('The original estimator did not return finite values for this dataset.')
  changed=float(np.max(np.abs(filled[~mask]-X[~mask])))
  out['metrics']=[metric('Cells estimated',int(mask.sum())),metric('Complete calibration rows',int(complete.sum())),metric('Largest observed-value change',changed)]
  out['charts']=[bars('Where were measurements missing?',names,mask.sum(0),'Missing cells'),{'kind':'heatmap','title':'Your data before and after estimation','before':X.tolist(),'after':filled.tolist()}]
  out['table']={'columns':['Observation','Variable','Estimated value'],'rows':[[int(i)+1,names[j],float(filled[i,j])] for i,j in np.argwhere(mask)]}
  out['insight']='These are estimates for genuinely missing values, whose true values are unknown. No accuracy score can be calculated for those cells. Check whether observed values were preserved; use the built-in example to examine reconstruction against known values.'
  out['snippet']='from PCAFill.pca_fill import pca_fill\ncompleted = pca_fill(data=uploaded_inputs)'
 elif tool=='ordering':
  from spca.spca import spca
  order=spca(X,plotting=False);Z=(X-X.mean(0))/X.std(0);total=np.var(Z,axis=0).sum();res=Z.copy();remaining=list(range(d));covered=[]
  for col in order[:-1]:
   idx=remaining.index(int(col));direction=res[:,idx:idx+1];rest=np.delete(res,idx,axis=1);res=rest-direction@((rest.T@direction)/(direction.T@direction)).T
   covered.append(1-np.var(res,axis=0).sum()/total);remaining.remove(int(col))
  covered.append(1.);increment=np.diff([0]+covered)*100;keep=p['keep'];ordered=[names[i] for i in order]
  out['metrics']=[metric('First variable',ordered[0]),metric('Variables retained',keep),metric('Variance represented',covered[keep-1]*100,'%')]
  out['charts']=[bars('Which columns add independent variation?',ordered,increment,'Incremental variance (%)'),bars('Coverage as columns are retained',[str(i+1) for i in range(d)],np.array(covered)*100,'Cumulative variance (%)')]
  for c in out['charts']:c['selected']=keep
  out['table']={'columns':['Rank','Column','Incremental variance (%)'],'rows':[[i+1,ordered[i],float(increment[i])] for i in range(d)]}
  out['insight']='The ranking is computed on your selected input columns. It describes variance representation, not causal importance or supervised prediction value.'
  out['snippet']='from spca.spca import spca\norder = spca(data=uploaded_inputs, plotting=False)'
 elif tool in ('pca','pls','clusterpls','propensity'):
  from sklearn.model_selection import train_test_split
  action=p.get('action');stratify=Y if tool=='propensity' and action=='discrete' else None
  if Y is None:
   Xt,Xv=train_test_split(X,test_size=.25,random_state=42);Yt=Yv=None
  else:Xt,Xv,Yt,Yv=train_test_split(X,Y,test_size=.25,random_state=42,stratify=stratify)
  out['dataset']+='A reproducible random 75/25 training/test split is used (seed 42); this is not a time-series validation. '
  if tool=='pca':
   from pca_nipals.pca import PcaClass
   m=PcaClass().fit(Xt,n_component=p['components']);e=m.evaluation(xtest=Xv)
   out['metrics']=[metric('Training rows',len(Xt)),metric('Training X variance',float(m.Rsquared[-1]),'%'),metric('Test reconstruction RMSE',rmse(Xv,e.xhat))]
   out['charts']=[scatter('Training observations in PCA score space',m.T[:,0],m.T[:,1] if p['components']>1 else np.zeros(len(Xt)),'PC 1 score','PC 2 score' if p['components']>1 else 'Zero reference'),bars('Variation retained by the model',[str(i+1) for i in range(p['components'])],m.Rsquared,'Training variance (%)')]
   out['table']={'columns':['Test observation','PC 1','Reconstruction SPE'],'rows':[[i+1,float(e.tscore[i,0]),float(np.asarray(e.spe).ravel()[i])] for i in range(len(Xv))]}
   out['insight']='The model was fitted only on the training split of your file. Reconstruction error is calculated on the held-out rows; it depends on your selected columns and their scales.'
   out['snippet']='model = PcaClass().fit(X_train, n_component=n_components)\nresult = model.evaluation(xtest=X_test)'
  elif tool in ('pls','clusterpls'):
   if tool=='pls':
    from pls_nipals.pls import PlsClass
    m=PlsClass().fit(Xt,Yt,n_component=p['components']);pred=m.evaluation(Xv).yfit
   else:
    from CB_PLS import CB_PLS
    m=CB_PLS();m.Train(Xt,Yt,1,K=p['clusters'],Nrepeat=3,ploting_clusters=False);pred,_=m.evaluator(Xv)
   if not np.isfinite(pred).all():raise ValueError('The original model did not return finite predictions.')
   out['metrics']=[metric('Training rows',len(Xt)),metric('Test rows',len(Xv)),metric('Test prediction RMSE',rmse(Yv,pred))]
   out['charts']=[scatter('Predictions for held-out rows',Yv[:,0],pred[:,0],'Observed '+outputs[0],'Predicted '+outputs[0]),scatter('Where prediction errors remain',pred[:,0],pred[:,0]-Yv[:,0],'Predicted '+outputs[0],'Predicted minus observed')]
   out['table']={'columns':['Test row']+['Observed '+h for h in outputs]+['Predicted '+h for h in outputs],'rows':[[i+1]+Yv[i].tolist()+pred[i].tolist() for i in range(len(Xv))]}
   out['insight']='These are predictions on held-out rows from your uploaded file. The plots show the first selected output; the table contains every selected output. A small random split does not establish performance on future populations or time periods.'
   out['snippet']=('model = PlsClass().fit(X_train, Y_train, n_component=n_components)\nprediction = model.evaluation(X_test).yfit' if tool=='pls' else 'model = CB_PLS()\nmodel.Train(X_train, Y_train, 1, K=n_clusters, Nrepeat=3, ploting_clusters=False)\nprediction, _ = model.evaluator(X_test)')
  else:
   from auto_propensity import PropensityModelBuilder,make_from_config,score_and_ll
   b=PropensityModelBuilder(Xt,Yt,action_type=action,random_state=42);r=b.tune(allow_nonparametric=False,allow_dimred=False,allow_ann=False,verbose=False)
   m=make_from_config(Xt,Yt,r['config'],random_state=42);scores,ll,_=score_and_ll(m,Xv,Yv)
   hist,edges=np.histogram(scores,bins=10);out['config']['fitted_configuration']=r['config']
   out['metrics']=[metric('Training rows',len(Xt)),metric('Test log likelihood',ll),metric('Median score',float(np.median(scores)))]
   out['charts']=[bars('Support for the actions in your file',[f'{x:.2f}' for x in edges[:-1]],hist,'Test observations'),scatter('Individual held-out action scores',np.arange(len(scores))+1,scores,'Test observation','Probability' if action=='discrete' else 'Density')]
   out['table']={'columns':['Test row','Action (numeric code for categories)','Score'],'rows':[[i+1,float(Yv[i]),float(scores[i])] for i in range(len(scores))]}
   if action=='discrete':
    from uploads import parse_upload
    headers,rows,_=parse_upload(upload,tool);labels=sorted(set(str(row[headers.index(outputs[0])]) for row in rows))
    out['config']['category_codes']={str(i):label for i,label in enumerate(labels)}
   out['insight']='Scores describe support for historical action assignment, not a causal effect or an outcome forecast. Continuous-action scores are densities. The full repository supports broader searches than this bounded interface.'
   out['snippet']='builder = PropensityModelBuilder(X_train, A_train, action_type=action_type)\nresult = builder.tune(allow_nonparametric=False, allow_dimred=False, allow_ann=False, verbose=False)\nmodel = make_from_config(X_train, A_train, result["config"])\nscores, avg_ll, _ = score_and_ll(model, X_test, A_test)'
 elif tool=='clusters':
  from kmeansPro import kmeansPro
  m=kmeansPro();m.fit(X,k=p['clusters'],Num_repeat=p['restarts'])
  if not np.isfinite(m.centers).all():raise ValueError('The cluster fit returned an empty or invalid group; try fewer clusters.')
  out['metrics']=[metric('Rows grouped',n),metric('Clusters',int(m.NumCluster)),metric('Distance-to-center sum',float(m.goodness))]
  counts=np.bincount(m.idx.ravel().astype(int),minlength=m.NumCluster)
  out['charts']=[scatter('Your observations grouped by the original code',X[:,0],X[:,1],names[0],names[1],m.idx),bars('Group membership counts',[str(i+1) for i in range(m.NumCluster)],counts,'Rows')]
  out['table']={'columns':['Observation','Group']+names,'rows':[[i+1,int(m.idx.ravel()[i])+1]+X[i].tolist() for i in range(n)]}
  out['insight']='Clustering uses all selected inputs in their original units; the plot shows the first two. Different scales can dominate distance. Groups are mathematical partitions and need interpretation in your context.'
  out['snippet']='model = kmeansPro()\nmodel.fit(uploaded_inputs, k=n_clusters, Num_repeat=n_restarts)'
 elif tool=='nullspace':
  from nspls import null_space as ns
  target=np.array(selection.get('target'),dtype=float)
  if target.shape!=(len(outputs),) or not np.isfinite(target).all() or np.any(np.abs(target)>1e8):raise ValueError('Enter one finite desired value per output.')
  result=ns.null_space_all_col(X,Y,Y_des=target.reshape(1,-1),n_component=min(3,d),number_points=p['points'],model_inversion=1)
  if result is None:raise ValueError('The fitted model has no usable null space for these columns.')
  _,inputs,values=result;inputs,values=inputs[:p['points']],values[:p['points']]
  if not len(inputs):raise ValueError('No admissible alternatives were found for your target. Try a target within the observed output range.')
  out['metrics']=[metric('Alternatives',len(inputs)),metric('Calibration rows',n),metric('Largest target difference',float(np.max(np.abs(values-target))))]
  out['charts']=[scatter('Alternative model inputs',inputs[:,0],inputs[:,1],names[0],names[1]),scatter('Modeled deviation from your target',np.arange(len(values))+1,values[:,0]-target[0],'Alternative','Output minus target')]
  out['table']={'columns':names+outputs,'rows':np.c_[inputs,values].tolist()}
  out['insight']='Alternatives preserve your fitted model’s output. They have not been checked against physical, operational, or experimental feasibility constraints.'
  out['config']['target']=target.tolist();out['snippet']='_, alternative_inputs, modeled_outputs = null_space.null_space_all_col(\n    X, Y, Y_des=target, n_component=3, number_points=n_points, model_inversion=1)'
 return out
