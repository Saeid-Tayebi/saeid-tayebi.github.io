"""Bounded, in-memory CSV/XLSX ingestion. No uploaded files are written to disk."""
import base64,csv,io,math,zipfile
import numpy as np
MAX_FILE=48*1024
CAPS={'missing':(60,6),'ordering':(60,6),'propensity':(120,5),'pca':(80,6),'pls':(80,8),'clusters':(60,4),'nullspace':(50,6),'clusterpls':(80,6)}

def parse_upload(upload,tool):
 if tool not in CAPS or not isinstance(upload,dict) or set(upload)!={'name','content'}:raise ValueError('Choose a CSV or .xlsx file.')
 name=upload['name'];content=upload['content']
 if not isinstance(name,str) or not isinstance(content,str) or len(name)>200 or len(content)>65536:raise ValueError('File exceeds the 48 KB limit.')
 try:raw=base64.b64decode(content,validate=True)
 except Exception:raise ValueError('The uploaded file could not be decoded.')
 if not raw or len(raw)>MAX_FILE:raise ValueError('Choose a nonempty file no larger than 48 KB.')
 maxrows,maxcols=CAPS[tool]
 if name.lower().endswith('.csv'):
  try:text=raw.decode('utf-8-sig')
  except UnicodeDecodeError:raise ValueError('Save CSV files with UTF-8 encoding.')
  try:dialect=csv.Sniffer().sniff(text[:4096],delimiters=',;\t')
  except csv.Error:dialect=csv.excel
  rows=[]
  try:
   for row in csv.reader(io.StringIO(text),dialect):
    if len(row)>maxcols:raise ValueError(f'This tool accepts at most {maxcols} file columns.')
    if any(str(v).strip() for v in row):rows.append(row)
    if len(rows)>maxrows+1:raise ValueError(f'This tool accepts at most {maxrows} data rows.')
  except csv.Error:raise ValueError('The CSV structure could not be read.')
 elif name.lower().endswith('.xlsx'):
  try:
   with zipfile.ZipFile(io.BytesIO(raw)) as z:
    entries=z.infolist()
    if len(entries)>100 or sum(x.file_size for x in entries)>2*1024*1024 or any(x.flag_bits&1 for x in entries):raise ValueError('Workbook is too large after decompression or is encrypted.')
   from openpyxl import load_workbook
   book=load_workbook(io.BytesIO(raw),read_only=True,data_only=False,keep_links=False)
   try:
    sheet=book.worksheets[0]
    if (sheet.max_row or 0)>maxrows+1 or (sheet.max_column or 0)>maxcols:raise ValueError(f'The first sheet must fit within {maxrows} data rows and {maxcols} columns. Remove unused formatted rows/columns if necessary.')
    sheet.reset_dimensions();rows=[]
    for record in sheet.iter_rows(max_row=maxrows+2,max_col=maxcols+1):
     row=[]
     for cell in record:
      if cell.data_type=='f':raise ValueError('Replace Excel formulas with values before uploading.')
      value=cell.value
      if value is not None and not isinstance(value,(str,int,float,bool)):raise ValueError('Use numeric or text cells; dates and special cell types are not supported.')
      row.append('' if value is None else value)
     while row and row[-1]=='':row.pop()
     if row:
      if len(row)>maxcols:raise ValueError(f'This tool accepts at most {maxcols} file columns.')
      rows.append(row)
     if len(rows)>maxrows+1:raise ValueError(f'This tool accepts at most {maxrows} data rows.')
   finally:book.close()
  except ValueError:raise
  except Exception:raise ValueError('The Excel workbook could not be read. Use an ordinary .xlsx file with values on the first sheet.')
 else:raise ValueError('Supported formats are .csv and .xlsx; legacy .xls and macro workbooks are not supported.')
 if len(rows)<2:raise ValueError('Include a header row followed by data rows.')
 headers=[str(x).strip() for x in rows[0]]
 if not headers or any(not x or len(x)>60 for x in headers) or len(set(headers))!=len(headers):raise ValueError('Use unique, nonempty column headers of at most 60 characters.')
 width=len(headers);table=[]
 for record in rows[1:]:
  if len(record)>width:raise ValueError('Some rows contain more fields than the header.')
  table.append(list(record)+['']*(width-len(record)))
 def number(v):
  if str(v).strip().lower() in ('','na','nan','null','n/a'):return float('nan')
  try:value=float(v)
  except (ValueError,TypeError):raise ValueError('Text column')
  if not math.isfinite(value) or abs(value)>1e8:raise ValueError('Values must be finite and within ±100,000,000.')
  return value
 columns=[]
 for j,h in enumerate(headers):
  try:values=[number(row[j]) for row in table];numeric=True;missing=sum(np.isnan(values))
  except ValueError:numeric=False;missing=sum(str(row[j]).strip()=='' for row in table)
  columns.append({'name':h,'numeric':numeric,'missing':int(missing)})
 return headers,table,columns

def inspect(upload,tool):
 headers,table,columns=parse_upload(upload,tool)
 return {'columns':columns,'rows':len(table),'maxrows':CAPS[tool][0],'maxcols':CAPS[tool][1],'preview':table[:5],'privacy':'Processed in memory; not saved or shared through the example cache.'}

def selected_data(upload,tool,selection,params):
 headers,table,columns=parse_upload(upload,tool)
 if not isinstance(selection,dict) or set(selection)-{'features','outputs','target'}:raise ValueError('Choose input and output columns.')
 features=selection.get('features');outputs=selection.get('outputs',[])
 if not isinstance(features,list) or not 2<=len(features)<=6 or len(set(features))!=len(features) or any(x not in headers for x in features):raise ValueError('Choose 2–6 distinct numeric input columns.')
 if not isinstance(outputs,list) or len(outputs)>2 or len(set(outputs))!=len(outputs) or any(x not in headers or x in features for x in outputs):raise ValueError('Choose distinct output columns separate from inputs (at most two).')
 X=np.array([[float(row[headers.index(h)]) if str(row[headers.index(h)]).strip().lower() not in ('','na','nan','null','n/a') else np.nan for h in features] for row in table])
 if np.any(np.abs(X[np.isfinite(X)])>1e8) or np.isinf(X).any():raise ValueError('Numeric values must be finite and within ±100,000,000.')
 if tool!='missing' and np.isnan(X).any():raise ValueError('The selected input columns contain missing values. Fill them first or use the missing-data tool.')
 if np.any(np.nanstd(X,axis=0)<1e-10):raise ValueError('Remove constant or near-constant input columns.')
 Y=None
 if tool in ('pls','clusterpls','nullspace','propensity'):
  if not outputs:raise ValueError('Choose at least one output or action column.')
  if tool=='propensity':
   if len(outputs)!=1:raise ValueError('Choose one action column.')
   vals=[row[headers.index(outputs[0])] for row in table]
   if any(str(x).strip()=='' for x in vals):raise ValueError('The action column contains missing values.')
   if params['action']=='discrete':
    labels,Y=np.unique([str(v) for v in vals],return_inverse=True)
    if not 2<=len(labels)<=3 or min(np.bincount(Y))<8:raise ValueError('Discrete actions need 2–3 classes, each with at least 8 observations.')
   else:Y=np.array(vals,dtype=float)
  else:Y=np.array([[row[headers.index(h)] for h in outputs] for row in table],dtype=float)
  if not np.isfinite(Y).all() or np.any(np.abs(Y)>1e8):raise ValueError('Outputs/actions must be complete, finite, and within ±100,000,000.')
  if np.any(np.std(Y,axis=0)<1e-10):raise ValueError('Outputs/actions must vary across observations.')
 if len(X)<(40 if tool=='propensity' else 20):raise ValueError('Provide at least '+('40' if tool=='propensity' else '20')+' data rows.')
 if tool in ('pca','pls') and params['components']>=len(features):raise ValueError('Choose fewer components than input columns for this small-data demo.')
 if tool=='ordering' and params['keep']>len(features):raise ValueError('Variables retained cannot exceed selected input columns.')
 if tool=='nullspace' and (len(features)<3 or len(outputs)>=3):raise ValueError('Null-space exploration needs at least three inputs and one or two outputs.')
 return X,Y,features,outputs,selection
