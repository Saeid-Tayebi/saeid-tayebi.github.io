"""Adapters around unmodified public implementations; one operation per subprocess."""
import ast
import contextlib
import io
import json
import os
import sys
import warnings
from pathlib import Path
os.environ.setdefault('MPLBACKEND', 'Agg')
os.environ.setdefault('MPLCONFIGDIR', '/tmp/portfolio-mpl')
import numpy as np
VENDOR = Path(__file__).parent / 'vendor'

REPOS = {
 'missing':'HandiMissingDataEstimaor', 'ordering':'SelectivePCA-Data-Reordering-Tool',
 'propensity':'AutoPropensity', 'pca':'pca_nipals', 'pls':'pls_nipals',
 'clusters':'KMeansPro', 'nullspace':'NullSpaceExplorer', 'clusterpls':'cluster-based-pls'}
LIMITS = {
 'missing': {'missing':[10,20,25], 'seed':[42,7,73]},
 'ordering': {'keep':[1,2,3,4,5]},
 'propensity': {'samples':[120,200,300], 'action':['discrete','continuous']},
 'pca': {'components':[1,2,3], 'seed':[42,7,73]},
 'pls': {'components':[1,2,3], 'seed':[42,7,73]},
 'clusters': {'clusters':[2,3,4], 'restarts':[3,5,10]},
 'nullspace': {'points':[10,20,30], 'seed':[42,7,73]},
 'clusterpls': {'clusters':[1,2,3], 'seed':[42,7,73]}}

def validate(tool, values):
 if tool not in LIMITS or not isinstance(values,dict) or set(values)!=set(LIMITS[tool]):
  raise ValueError('Choose a supported tool and its listed settings.')
 for key, val in values.items():
  if type(val) not in (int,str) or val not in LIMITS[tool][key]:
   raise ValueError('A setting exceeds the demonstration limits.')
 return values

def array_from_example(repo, name):
 """Read only the literal array assignment from the upstream example; do not run it."""
 source=(VENDOR/repo/'example_usage.py').read_text()
 tree=ast.parse(source)
 for node in tree.body:
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets):
   call=node.value
   if isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and call.func.attr=='array':
    return np.array(ast.literal_eval(call.args[0]), dtype=float)
 raise ValueError('Expected example dataset not found.')

def scatter(title,x,y,xlabel,ylabel,groups=None):
 return dict(kind='scatter',title=title,x=np.asarray(x).ravel().tolist(),y=np.asarray(y).ravel().tolist(),xlabel=xlabel,ylabel=ylabel,groups=None if groups is None else np.asarray(groups).ravel().astype(int).tolist())
def bars(title,labels,values,ylabel):
 return dict(kind='bar',title=title,labels=labels,values=np.asarray(values).ravel().tolist(),ylabel=ylabel)
def metric(label,value,unit=''):
 return dict(label=label,value=value,unit=unit)
def rmse(a,b):return float(np.sqrt(np.mean((np.asarray(a)-np.asarray(b))**2)))

def run(tool,params):
 p=validate(tool,params);repo=REPOS[tool];sys.path.insert(0,str(VENDOR/repo))
 seed=p.get('seed',42);np.random.seed(seed);rng=np.random.RandomState(seed)
 out={'charts':[], 'metrics':[], 'table':{}, 'repo':repo, 'seed':seed}
 if tool=='missing':
  from PCAFill.pca_fill import pca_fill
  # Same synthetic construction as upstream example_usage.py: X @ Beta, 30 x 3.
  X=rng.rand(30,4);truth=X@(rng.rand(4,3)*2-1);data=truth.copy()
  # Keep 18 complete rows so the example always has a usable calibration block.
  eligible=np.arange(18*3,30*3)
  chosen=rng.choice(eligible,size=round(data.size*p['missing']/100),replace=False)
  data.flat[chosen]=np.nan;mask=np.isnan(data)
  filled=pca_fill(data)
  if not np.all(np.isfinite(filled)):raise ValueError('The upstream estimator did not return finite results for this setting.')
  baseline=np.tile(np.nanmean(data,axis=0),(30,1))
  out['metrics']=[metric('Values reconstructed',int(mask.sum())),metric('Hidden-value RMSE',rmse(truth[mask],filled[mask])),metric('Mean-fill RMSE',rmse(truth[mask],baseline[mask]))]
  out['charts']=[scatter('Did reconstruction recover the hidden values?',truth[mask],filled[mask],'Known value','Estimated value'),dict(kind='heatmap',title='Missing cells → completed dataset',before=data.tolist(),after=filled.tolist(),xlabel='Variable',ylabel='Observation')]
  out['insight']='Compare the reconstruction error with simple mean filling. Lower error is better; the example does not guarantee a gain on every dataset. Rows with no observed information cannot be reliably reconstructed.'
  out['dataset']='30 observations × 3 variables; seeded adaptation of the repository’s synthetic X @ Beta example. Missingness is restricted to the last 12 rows to retain calibration data.'
  out['snippet']='from PCAFill.pca_fill import pca_fill\ncompleted = pca_fill(data=incomplete_data)'
  out['source']='PCAFill/pca_fill.py';out['example']='example_usage.py'
  out['table']={'columns':['Known','Estimated','Difference'], 'rows':np.c_[truth[mask],filled[mask],filled[mask]-truth[mask]].tolist()}
 elif tool=='ordering':
  from spca.spca import spca
  X=array_from_example(repo,'OriginalData');order=spca(X,plotting=False)
  # Reproduce the variance accounting from spca() for display only, using its returned ordering.
  Z=(X-X.mean(0))/X.std(0);total=np.var(Z,axis=0).sum();res=Z.copy();covered=[];remaining=list(range(X.shape[1]))
  for col in order[:-1]:
   idx=remaining.index(int(col));direction=res[:,idx:idx+1];rest=np.delete(res,idx,axis=1)
   residual=rest-direction@((rest.T@direction)/(direction.T@direction)).T
   covered.append(1-np.var(residual,axis=0).sum()/total);res=residual;remaining.remove(int(col))
  covered.append(1.0);keep=p['keep'];increment=np.diff([0]+covered)*100
  out['metrics']=[metric('First variable','V'+str(order[0]+1)),metric('Variables selected',keep),metric('Variance represented',float(covered[keep-1]*100),'%')]
  out['charts']=[bars('Which variables bring additional information?',['V'+str(i+1) for i in order],increment,'Incremental variance (%)'),bars('How much information accumulates?',[str(i+1)+' vars' for i in range(5)],np.array(covered)*100,'Cumulative variance (%)')]
  out['charts'][0]['selected']=keep;out['charts'][1]['selected']=keep
  out['insight']='The order comes directly from spca(). The highlighted selection shows the tradeoff between fewer variables and represented variance; it is not a supervised feature-importance score.'
  out['dataset']='The repository’s exact 10 × 5 OriginalData example. Variance accounting follows the source routine; the selected-variable count changes the interpretation, not the fitted order.'
  out['snippet']='from spca.spca import spca\norder = spca(data=OriginalData, plotting=False)';out['source']='spca/spca.py';out['example']='example_usage.py'
  out['table']={'columns':['Rank','Original variable','Incremental variance (%)'], 'rows':[[i+1,'V'+str(int(v)+1),float(increment[i])] for i,v in enumerate(order)]}
 elif tool=='propensity':
  from sklearn.model_selection import train_test_split
  from auto_propensity import PropensityModelBuilder,make_from_config,score_and_ll
  n=p['samples'];X=rng.normal(size=(n,4));action=p['action']
  if action=='discrete':
   A=np.argmax(X@rng.normal(size=(4,3))+rng.normal(scale=.5,size=(n,3)),axis=1)
  else:A=X@rng.normal(size=4)+rng.normal(scale=.7,size=n)
  Xt,Xv,At,Av=train_test_split(X,A,test_size=.25,random_state=42,stratify=A if action=='discrete' else None)
  b=PropensityModelBuilder(Xt,At,action_type=action,random_state=42);b.trace_on=True
  result=b.tune(allow_nonparametric=False,allow_dimred=False,allow_ann=False,verbose=False)
  model=make_from_config(Xt,At,result['config'],random_state=42)
  scores,ll,_=score_and_ll(model,Xv,Av)
  hist,edges=np.histogram(scores,bins=10)
  out['metrics']=[metric('Training observations',len(Xt)),metric('Held-out log likelihood',float(ll)),metric('Median '+('probability' if action=='discrete' else 'density'),float(np.median(scores)))]
  out['charts']=[bars('How supported were the observed actions?',[f'{x:.2f}' for x in edges[:-1]],hist,'Held-out observations'),scatter('Scores for held-out actions',np.arange(len(scores))+1,scores,'Held-out observation','Probability' if action=='discrete' else 'Density')]
  out['insight']='These scores describe historical action assignment, not outcome quality or a causal treatment effect. Low scores flag poorly supported observed actions. Continuous-action scores are densities and can exceed one.'
  out['dataset']='Seed-42 adaptation of usecase_basic.py: 120–300 observations, 4 state variables, 3 discrete actions or 1 continuous action. Parametric search only; dimension reduction, neural networks and nonparametric search disabled for this demo.'
  out['snippet']='builder = PropensityModelBuilder(X_train, A_train, action_type=action_type)\nresult = builder.tune(allow_nonparametric=False, allow_dimred=False, allow_ann=False, verbose=False)\npm = make_from_config(X_train, A_train, result["config"])\np, avg_ll, _ = score_and_ll(pm, X_test, A_test)'
  out['source']='auto_propensity/builder.py';out['example']='usecase_basic.py';out['config']=result['config']
  out['table']={'columns':['Held-out observation','Observed action','Score'], 'rows':[[i+1,float(Av[i]),float(scores[i])] for i in range(len(scores))]}
 elif tool in ['pca','pls']:
  X=rng.rand(30,4);Beta=rng.rand(4,2)*2-1;Y=X@Beta;Xtest=rng.rand(10,4);Ytest=Xtest@Beta;a=p['components']
  if tool=='pca':
   from pca_nipals.pca import PcaClass
   model=PcaClass().fit(X,n_component=a);ev=model.evaluation(xtest=Xtest)
   out['metrics']=[metric('Components',a),metric('Training X variance',float(model.Rsquared[-1]),'%'),metric('Held-out reconstruction RMSE',rmse(Xtest,ev.xhat))]
   out['charts']=[scatter('How observations map into model space',model.T[:,0],model.T[:,1] if a>1 else np.zeros(30),'PC 1 score','PC 2 score' if a>1 else 'Zero reference'),bars('Variance represented as components are added',[str(i+1) for i in range(a)],model.Rsquared,'Training X variance (%)')]
   out['snippet']='from pca_nipals.pca import PcaClass\nmodel = PcaClass().fit(X, n_component=n_components)\nresult = model.evaluation(xtest=X_test)';out['source']='pca_nipals/pca.py';out['example']='example_usage.py'
   out['insight']='PCA compresses variation without using an outcome. Compare variance represented with reconstruction on separate synthetic observations; more components can preserve more detail.'
   out['table']={'columns':['Observation','PC 1 score','Reconstruction SPE'], 'rows':[[i+1,float(ev.tscore[i,0]),float(np.asarray(ev.spe).reshape(-1)[i])] for i in range(10)]}
  else:
   from pls_nipals.pls import PlsClass
   model=PlsClass().fit(X,Y,n_component=a);ev=model.evaluation(Xtest)
   out['metrics']=[metric('Components',a),metric('Held-out prediction RMSE',rmse(Ytest,ev.yfit)),metric('Held-out observations',10)]
   out['charts']=[scatter('Can the model predict unseen outputs?',Ytest[:,0],ev.yfit[:,0],'Known output 1','Predicted output 1'),scatter('Where are prediction errors?',ev.yfit[:,0],ev.yfit[:,0]-Ytest[:,0],'Predicted output 1','Prediction minus known value')]
   out['snippet']='from pls_nipals.pls import PlsClass\nmodel = PlsClass().fit(X, Y, n_component=n_components)\nresult = model.evaluation(X_test)';out['source']='pls_nipals/pls.py';out['example']='README.md'
   out['insight']='PLS uses the relationship between inputs and outputs. These held-out predictions use the repository’s synthetic linear data pattern, not experimental validation or real-world accuracy.'
   out['table']={'columns':['Known output 1','Predicted output 1','Residual'], 'rows':np.c_[Ytest[:,0],ev.yfit[:,0],ev.yfit[:,0]-Ytest[:,0]].tolist()}
  out['dataset']='Seeded version of the repository example: 30 calibration observations × 4 inputs; 10 separate test observations. For PLS, 2 outputs generated as X @ Beta.'
 elif tool=='clusters':
  from kmeansPro import kmeansPro
  X=rng.rand(60,2);m=kmeansPro();m.fit(X,k=p['clusters'],Num_repeat=p['restarts'])
  out['metrics']=[metric('Groups',int(m.NumCluster)),metric('Observations',60),metric('Distance-to-center sum',float(m.goodness))]
  out['charts']=[scatter('Which observations share a neighborhood?',X[:,0],X[:,1],'Variable 1','Variable 2',m.idx),bars('How large is each group?',[str(i+1) for i in range(m.NumCluster)],m.clustr_counts,'Observations')]
  out['insight']='The example uses uniform random data, just like code_executor.py. Clustering partitions that space; colored groups alone do not establish that natural populations exist. The reported objective is the source’s sum of distances, not squared inertia.'
  out['dataset']='Seed-42 adaptation of code_executor.py: 60 × 2 uniform observations instead of 100; 2–4 clusters and 3–10 restarts.'
  out['snippet']='from kmeansPro import kmeansPro\nmodel = kmeansPro()\nmodel.fit(datapoints, k=n_clusters, Num_repeat=n_restarts)';out['source']='kmeansPro.py';out['example']='code_executor.py'
  out['table']={'columns':['Variable 1','Variable 2','Group'], 'rows':np.c_[X,m.idx.ravel()+1].tolist()}
 elif tool=='nullspace':
  from nspls import null_space as ns
  X=rng.rand(30,4);Beta=rng.rand(4,2)*2-1;Y=X@Beta;target=rng.rand(1,4)@Beta
  result=ns.null_space_all_col(X,Y,Y_des=target,n_component=3,number_points=p['points'],model_inversion=1)
  if result is None:raise ValueError('No null-space result was returned.')
  T,inputs,outputs=result
  inputs,outputs=inputs[:p["points"]],outputs[:p["points"]]
  if len(inputs)==0:raise ValueError('No admissible points were found for this target. Try another example seed.')
  delta=np.max(np.abs(outputs-target))
  out['metrics']=[metric('Alternatives returned',len(inputs)),metric('Requested points',p['points']),metric('Largest modeled target difference',float(delta))]
  out['charts']=[scatter('Different inputs can share a modeled target',inputs[:,0],inputs[:,1],'Input 1','Input 2'),scatter('Do alternative inputs retain the modeled output?',np.arange(len(outputs))+1,outputs[:,0]-target[0,0],'Alternative input','Output 1 minus target')]
  out['insight']='This is model-based equivalence: alternative inputs preserve the fitted model’s output. It does not establish physical feasibility, safety, or equivalent experimental outcomes.'
  out['dataset']='Seeded adaptation of example_usage.py: 30 × 4 calibration inputs, 2 linear outputs, one synthetic target and 10–30 requested alternatives.'
  out['snippet']='from nspls import null_space\nT, X_alt, Y_alt = null_space.null_space_all_col(\n    X, Y, Y_des=target, n_component=3, number_points=20, model_inversion=1)';out['source']='nspls/null_space.py';out['example']='example_usage.py'
  out['table']={'columns':['Input 1','Input 2','Output 1','Output 2'], 'rows':np.c_[inputs[:,:2],outputs].tolist()}
 elif tool=='clusterpls':
  from CB_PLS import CB_PLS
  X=rng.rand(60,3);Xtest=rng.rand(10,3);Beta=rng.rand(3,3)*2-1;Y=X@Beta.T;truth=Xtest@Beta.T
  m=CB_PLS();m.Train(X,Y,1,K=p['clusters'],Nrepeat=3,ploting_clusters=False)
  pred,_=m.evaluator(Xtest,None,truth)
  base=CB_PLS();base.Train(X,Y,1,K=1,Nrepeat=1,ploting_clusters=False);predbase,_=base.evaluator(Xtest,None,truth)
  out['metrics']=[metric('Actual input clusters',int(m.clustere_str.NumCluster)),metric('Clustered prediction RMSE',rmse(truth,pred)),metric('Single-model RMSE',rmse(truth,predbase))]
  out['charts']=[scatter('Do clustered models predict unseen outputs?',truth[:,0],pred[:,0],'Known output 1','Predicted output 1'),scatter('How calibration inputs are grouped',X[:,0],X[:,1],'Input 1','Input 2',m.clustere_str.idx)]
  out['insight']='Compare the clustered model with one global model on the same held-out points. The upstream linear example may favor neither approach; it is not a reproduction of the microgel publication’s experimental results.'
  out['dataset']='Seeded adaptation of CB_pls_executer.py: 60 × 3 calibration inputs, 3 linear outputs, 10 test observations, input-space clustering only. Three initialization repeats; source may reduce the requested cluster count.'
  out['snippet']='from CB_PLS import CB_PLS\nmodel = CB_PLS()\nmodel.Train(X, Y, 1, K=n_clusters, Nrepeat=3, ploting_clusters=False)\nprediction, _ = model.evaluator(X_test, None, Y_test)';out['source']='CB_PLS.py';out['example']='CB_pls_executer.py'
  out['table']={'columns':['Known output 1','Predicted output 1','Single-model prediction'], 'rows':np.c_[truth[:,0],pred[:,0],predbase[:,0]].tolist()}
 out['settings']=p
 return out

def clean(value):
 if isinstance(value,dict):return {k:clean(v) for k,v in value.items()}
 if isinstance(value,(list,tuple)):return [clean(v) for v in value]
 if isinstance(value,np.ndarray):return clean(value.tolist())
 if isinstance(value,(np.integer,np.floating)):value=value.item()
 if isinstance(value,float) and not np.isfinite(value):return None
 return value

if __name__=='__main__':
 try:
  request=json.loads(sys.stdin.read(98305))
  with contextlib.redirect_stdout(io.StringIO()),warnings.catch_warnings():
   warnings.simplefilter('ignore')
   if request.get('operation')=='inspect':
    from uploads import inspect
    result=inspect(request['upload'],request['tool'])
   elif 'upload' in request:
    from uploaded_runs import run_uploaded
    result=run_uploaded(request['tool'],request['params'],request['upload'],request.get('selection'))
   else:result=run(request['tool'],request['params'])
  print(json.dumps(clean(result),allow_nan=False))
 except Exception as exc:
  print(json.dumps({'error':str(exc),'type':type(exc).__name__}));sys.exit(1)
